package sbp.api;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.validation.constraints.NotNull;
import org.hibernate.validator.constraints.Length;

public class Sneaker {
    @NotNull
    private String name;
    @NotNull
    private String image;
    @NotNull
    private String releaseDate;
    @NotNull
    private String brand;
    @NotNull
    private String model;
    @NotNull
    private String sku;
    @NotNull
    private String color;
    @NotNull
    private String itemCondition;
    @Length(min= 0, max= 2050)
    private String description;
    private long id;

    public Sneaker() {
        
    }
    public Sneaker(String nm, String im, String rDate, String brn, String mod, String sk, String clr, String ic, String dn) {
        name = nm;
        image = im;
        releaseDate = rDate;
        brand = brn;
        model = mod;
        sku= sk;
        color = clr;
        itemCondition= ic;
        description = dn;
        
    }
    public void setId(long r) {
        id = r;
    }
    public long returnId() {
        return id;
    }
    public String displaypic() {
        return image; 
    }
    public String displayName (){
        return name;
    }
    public String displayBrand (){
        return brand;
    }
    public String releaseDate() {
        return releaseDate;
    }
    
    public String displayModel (){
        return model;
    }
    public String displaySKU (){
        return sku;
    }
    public String displayColor (){
        return color;
    }
    public String displayItemCondition (){
        return itemCondition;
    }
    public String displayDescription (){
        return description;
    }
    
    
    public String setPic(String n) {
        image = n;
        return image;
    }
    public String setName (String n){
        name = n;
        return name;
    }
    public String setBrand (String n){
        return brand = n;
    }
    
    public String setModel (String n){
        return model= n;
    }
    public String setSKU (String n){
        return sku = n;
    }
    public String setColor (String n){
        return color= n;
    }
    public String setItemCondition (String n){
        return itemCondition = n;
    }
    public String setDescription (String n){
        return description= n;
    }
    public String setreleaseDate(String n) {
        return releaseDate = n;
    }
    
}

