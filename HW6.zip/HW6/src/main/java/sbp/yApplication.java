package sbp;

import io.dropwizard.Application;
import io.dropwizard.jdbi.DBIFactory;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import static org.eclipse.jetty.util.log.JettyLogHandler.config;
import sbp.db.SneakerDAO;
import sbp.resources.SneakerResource;

public class yApplication extends Application<yConfiguration> {

    public static void main(final String[] args) throws Exception {
        new yApplication().run(args);
    }

    @Override
    public String getName() {
        return "y";
    }

    @Override
    public void initialize(final Bootstrap<yConfiguration> bootstrap) {
        // TODO: application initialization
    }

    @Override
    public void run(final yConfiguration configuration,
                    final Environment environment) {
//        
//        final DBIFactory factory = new DBIFactory();
//    final DBI jdbi = factory.build(environment, config.getDataSourceFactory(), "postgresql");
//    final SneakerDAO dao = jdbi.onDemand(SneakerDAO.class);
//    environment.jersey().register(new SneakerResource(dao));
    }

}
