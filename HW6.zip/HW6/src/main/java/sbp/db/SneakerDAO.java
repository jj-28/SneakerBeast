/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sbp.db;

import org.skife.jdbi.v2.sqlobject.SqlQuery;
/**
 *
 * @author Jeffrey
 */
public interface SneakerDAO {
    
@SQLQuery("create")
    
}
